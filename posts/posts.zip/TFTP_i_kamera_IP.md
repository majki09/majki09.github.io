---
title: "temp"
description : "Obsługa pilota IR w Raspberry Pi"
weight: 1
date: 2019-07-13T10:29:23+05:30
tags:
- linux
- raspberry
- TFTP
- kamera
categories:
- linux
cover: "/images/remote.jpg"
draft: true
license: "BY-NC-SA"
---

> **UWAGA !**
> Ten poradnik dotyczy pakietu *lirc* i wersji kernela, które go obsługują. W nowszych (od release **4.19.y** w górę) *lirc* zastąpiony jest pakietem *gpio-ir*, który jesto obsługiwany zupełnie inaczej. Więcej info na dole strony [dole strony](#obsługa-z-nowymi-kernelami).

# Pan Pilot - czyli wstęp
**Piloty na podczerwień** powstały już bardzo dawno temu. Niektórzy pamiętają ten wynalazek jako coś, czym się włącza TV, wieżę, czy klimę. Ja pamiętam czasy, kiedy biegałem do telewizyjnego pudła, żeby zmienić kanał (były aż 3) albo podgłośnić czy ściszyć, no bo pilotów my jeszcze wtedy nie mieli. Takie czasy byli... A dzisiaj? Pykniemy sobie sterowanie maliną takim właśnie wiekowym wynalazkiem. Zapraszam :)

> Zanim ruszymy dalej upewnijmy się, że:  
> 
> - znasz podstawy elektroniki,
> - wiesz, co to jest GPIO,
> - znasz podstawowe komendy Linux'a i umiesz edytować pliki,
> - masz sprawne baterie w pilocie :)

# Czego potrzebujesz  
- RaspberryPi z **Raspbianem**,
- odbiornik IR, np **AT138B**, **TSOP32236** lub podobne,
- kondensator elektrolityczny **47uF** (najlepiej w obudowie do montażu przewlekanego),
- dowolny pilot zgodny z kodowaniem **RC-5** (u mnie to poczciwy pilot Cyfry+).



# Instalacja
## Hardware

W tym poradniku za przykład użyjemy sobie odbiornika **AT138B**. Inne odbiorniki wyglądają i działają analogicznie.  
Pinout: 
![pinout](/images/at138b_pinout.jpg "Pinout dla AT138B")

Podłączamy odbiornik do naszej Raspberry (na schemacie *uC*) analogicznie do schematu:

![text](/images/TFTP_server.png "Przykładowy schemat podłączenia AT138B")  

gdzie:

* 1 - OUT,
* 2 - GND,
* 3 - VS.


> **UWAGA!** Bardzo ważne jest to, żeby nie zignorować **kondensatora** między pinami **3**, a **2**! Kondensator umieszcza się po to, by "odszumić" linię zasilającą odbiornik. W przeciwnym razie **nie będziesz w stanie** poprawnie odczytać kodu wciśniętego na pilocie klawisza, a *irw* (o tym potem) zasypie Ci konsolę **krzakami**. W ramach eksperymentu, po skończonym projekcie uruchom *irw* i wypnij kondensator z układu, żeby przekonać się, o czym mowa.


## Instalujemy TFTP Server
1.  Instalujemy paczki *apt-get'em*:
    ```ssh
    sudo apt-get install lirc liblircclient-dev
    sudo apt-get install python-lirc
    ```

2. Dopisujemy *lirc* do modułów systemu, czyli plik `/etc/modules` (w nowszych dystrybucjach Raspbiana, od Wheezy w górę *lirc* jest już wpisany, należałoby jednak to sprawdzić - instrukcja taka sama, jak niżej):
    ```
    lirc_dev
    lirc_rpi gpio_in_pin=18
    ```
Dodatkowo ten wpis powinien być w pliku `/boot/config`, jeśli go tam nie ma to najlepiej dopisać go w ostatniej linii:
    ```
    dtoverlay=lirc-rpi,gpio_in_pin=18
	```

	> **UWAGA!** Przy *gpio_in_pin* podajesz własny numer **GPIO**, czyli tam, gdzie masz wpięty pin **OUT** odbiornika.  
	A także, jeśli musiałeś dopisywać/zmieniać powyższe 3 linie niestety musisz strzelić malinie miękki **restart** :)
3. Teraz odczytywanie kodów pilota powinno już działać - sprawdźmy to wywołując `mode2 -d /dev/lirc0`. Jeśli odbiornik jest zajęty przez inny proces i dostajemy taki komunikat:
    ```ssh
	pi@raspberrypi:~ $ mode2 -d /dev/lirc0
	Using driver default on device /dev/lirc0
	Cannot initiate device /dev/lirc0
	```
musimy zwolnić urządzenie *lirc0* i ponownie uruchomić odczytywanie:
	```ssh
	pi@raspberrypi:~ $ sudo /etc/init.d/lircd stop
	mode2 -d /dev/lirc0
	```
Teraz powinniśmy być w stanie odczytać wciskane klawisze na pilocie:
	```ssh
	pi@raspberrypi:~ $ mode2 -d /dev/lirc0
	Using driver default on device /dev/lirc0
	Trying device: /dev/lirc0
	Using device: /dev/lirc0
	space 16777215
	pulse 809
	space 957
	pulse 815
	space 933
	pulse 1729
	space 1844
	pulse 1703
	space 1845
	pulse 1704
	space 932
	pulse 841
	...
	```
> Jeśli kody pojawiają się mimo, że nie wciskasz żadnych klawiszy na pilocie (w sposób ciągły) na 99% masz problem z zasilaniem odbiornika lub linią danych. Osobiście miałem ten problem i gniotłem go dość długo (kilka dni), zanim okazało się, że potrzebny jest **kondensator** na linii zasilającej czujnik - tak jak na [schemacie](#hardware). 
> Przejście do następnego kroku poradnika ma sens jedynie wtedy, gdy wraz z wciskaniem klawiszy dostajesz w miarę stabilne odczyty.

# Konfiguracja

To, co teraz zrobisz zależy od tego, jaki masz **pilot**. Sprawdź na stronie [Remotes Database](http://lirc-remotes.sourceforge.net/remotes-table.html), czy Twój remote jest na liście i ściągnij gotową konfigurację. Dzięki temu trikowi możesz odpuścić sobie **krok 1.** konfiguracji i przejść od razu do **kroku nr. 2**.

1. Przypisujemy nazwy przycisków - uruchamiamy
	```ssh
	irrecord -d /dev/lirc0 ~/moj_pilot.conf
	```
	i jedziemy wg **instrukcji na ekranie**. Efekt powinien wyglądać tak jak tu:
	```ssh
	pi@raspberrypi:~ $ irrecord -d /dev/lirc0 ~/moj_pilot.conf
	Running as regular user pi
	Using driver default on device /dev/lirc0

	irrecord -  application for recording IR-codes for usage with lirc
	Copyright (C) 1998,1999 Christoph Bartelmus(lirc@bartelmus.de)

	This program will record the signals from your remote control
	and create a config file for lircd.

	A proper config file for lircd is maybe the most vital part of this
	package, so you should invest some time to create a working config
	file. Although I put a good deal of effort in this program it is often
	not possible to automatically recognize all features of a remote
	control. Often short-comings of the receiver hardware make it nearly
	impossible. If you have problems to create a config file READ THE
	DOCUMENTATION at https://sf.net/p/lirc-remotes/wiki

	If there already is a remote control of the same brand available at
	http://sf.net/p/lirc-remotes you might want to try using such a
	remote as a template. The config files already contains all
	parameters of the protocol used by remotes of a certain brand and
	knowing these parameters makes the job of this program much
	easier. There are also template files for the most common protocols
	available. Templates can be downloaded using irdb-get(1). You use a
	template file by providing the path of the file as a command line
	parameter.

	Please take the time to finish the file as described in
	https://sourceforge.net/p/lirc-remotes/wiki/Checklist/ an send it
	to  <lirc@bartelmus.de> so it can be made available to others.

	Press RETURN to continue.
	```
	Tutaj chodzi o to, żeby malina dobrze poznała nasz pilot - kodowanie, sekwencję bitów i poszczególne przyciski, które po kolei wyklikamy i nazwiemy.

	Dla porównania `lircd.conf` dla mojego pilota wygląda tak:
	```
	begin remote
	
	name  cyfra+
	bits           13
	flags RC5|CONST_LENGTH
	eps            30
	aeps          100
	
	one           836   937
	zero          836   937
	plead         816
	gap          113535
	toggle_bit_mask 0x800
	frequency    38000
	
		begin codes
			OK                       0x0297
			KEY_POWER                0x128C
			pilot                    0x128F
			progr                    0x028F
			plus                     0x12AF
			KEY_LEFT                 0x0295
			KEY_RIGHT                0x0296
			KEY_UP                   0x0290
			KEY_DOWN                 0x0291
			KEY_1                    0x1281
			KEY_2                    0x1282
			KEY_3                    0x1283
			KEY_4                    0x1284
			KEY_5                    0x1285
			KEY_6                    0x1286
			KEY_7                    0x1287
			KEY_8                    0x1288
			KEY_9                    0x1289
			KEY_0                    0x1280
			x                        0x02A1
			.>                       0x0293
			serw                     0x0292
			KEY_MENU                 0x02AA
			A                        0x02AB
			B                        0x02AC
			C                        0x02AD
			D                        0x02AE
			E                        0x02AF
			KEY_MUTE                 0x0286
			tv/sat                   0x12A8
		end codes
	
	end remote
	```
	
2. Teraz twój plik z zapisaną konfiguracją kopiujesz do `/etc/lirc`, ale najpierw zrób backup już istniejącego:
	```ssh
	sudo cp /etc/lirc/lircd.conf /etc/lirc/lircd.conf.bak
	sudo cp ~/moj_pilot.conf /etc/lirc/lircd.conf
	```

2. Odpalamy na nowo `lircd` i od tej pory `irw` powinien pokazać konkretne kody przycisków, gdy naciśniesz je na pilocie. U mnie przyciski są takie:
	```ssh
	pi@raspberrypi:~ $ sudo /etc/init.d/lircd start
	pi@raspberrypi:~ $ irw
	0000000000001281 00 KEY_1 cyfra+
	0000000000001287 01 KEY_7 cyfra+
	0000000000001284 00 KEY_4 cyfra+
	0000000000000290 00 KEY_UP cyfra+
	0000000000000291 00 KEY_DOWN cyfra+
	0000000000000296 00 KEY_RIGHT cyfra+
	0000000000000295 00 KEY_LEFT cyfra+
	0000000000000286 01 KEY_MUTE cyfra+
	0000000000001281 00 KEY_1 cyfra+
	000000000000028f 00 progr cyfra+
	```

3. Na koniec tworzymy **skrypty**, które będą wywoływały **akcje** po naciśnięciu przycisku. Edytujemy plik `lircrc`:
	```ssh
	sudo nano /etc/lirc/lircrc
	```
Wszystkie **akcje** programowane są w ten sposób:
	```
	begin							# start akcji
         prog = irexec				# proces obslugujacy wywolanie komendy, pozostawiamy niezmienione
         button = KEY_2				# nazwa przycisku, na ktory irexec ma wywolac akcje
         config = gpio write 29 1	# komenda do wywolania przez akcje
	end								# koniec akcji
	
	# RADIO
	begin
	     prog = irexec
	     button = KEY_PLUS
	     config = mplayer http://195.150.20.242:8000/rmf_fm
	end
	
    # OCZYSZCZACZ NA 2h - STEROWANIE DOMOTICZ
	begin
         prog = irexec
         button = KEY_0
         config = curl "http://adres:port/json.htm?type=command&param=switchlight&idx=111&switchcmd=On"
	end
	
	# VOLUME +
	begin
         prog = irexec
         button = KEY_UP
         config = sudo /usr/bin/amixer -q -M sset PCM 10%+
	end
	```
Zapisujemy wciskając *Ctrl+X*, potem klawiszem *T* potwierdzamy zapis i wychodzimy z *nano*.

4. Włączamy autostart `irexec'a` przy każdym starcie maliny - na końcu `/etc/rc.local` dodajemy
	```ssh
	irexec /etc/lirc/lircrc &
	```

> To nie wszystko, co potrafi `lirc`. Można też zaprogramować sekwencje przycisków (dla mnie **bomba**) i wiele innych ciekawych bajerów, ciekawskich po **szczegóły** odsyłam do [manuala](http://www.lirc.org/html/index.html).


# Testy

1. Wciskasz przyciski pilota i sprawdzasz, czy zapisane w `lircrc` komendy się wywołują.

2. **Koniec.** Jeśli wszystko działa tak, jak zaprogramowałeś to **moje gratulacje**, umiesz już sterować maliną za pomocą pilota. Możesz pochwalić się żonie i sąsiadowi :P

# Bonus
## Modyfikacja pliku `lircrc`

Po każdej zmianie pliku `lircrc` trzeba uruchomić na nowo `irexec`:

1. Kill'ujemy `irexec'a` (jeśli obecnie działa) i upewniamy się, że nie ma już żadnych uruchomionych `irexec'ów`:
```ssh
ps aux | grep irexec
```

2. Odpalamy nowy `irexec`, który załaduje już **nowy plik** `lircrc` (komendą `irexec -d` lub lepiej dla debugu `irexec` ).


## Linki

- [oficjalna strona LIRC](http://www.lirc.org/)
- [LIRC manual](http://www.lirc.org/html/index.html)
- [baza pilotów](http://lirc-remotes.sourceforge.net/remotes-table.html)  

## Obsługa z nowymi kernelami

W nowszych kernelach (od release **4.19.y** w górę) pakiet *lirc* został **porzucony** na rzecz nowszego *gpio-ir*. Niestety konfiguracja *gpio-ir* wykracza poza ramy tego wpisu, być może w niedalekiej przyszłości powstanie wpis o *gpio-ir*. 
W moim przypadku, po aktualizacji do nowego kernela mojej Raspberry Pi mój pilot z niewiadomych przyczyn **przestał działać**. Zajęło mi około tygodnia, żeby zgłębić temat i tak w nowym kernelu:

- nie ma *lirc* - jest za to *gpio-ir*, co prawda można włączyć **overlay** dla *lirc* w `\boot\config.txt\`, ale odbiornik wciąż nie działa,
- odbiornik wydaje się być "niezałączony" - na jego nóżce zasilania brak jest **3.3V** i nawet jeśli ustawimy mu w `\boot\config.txt` brak jest **pull-up'a** na linii sygnałowej - polecam sprawdzić to multimetrem w pierwszej kolejności.

Podczas całej batalii znalazłem zaledwie **2 wpisy** w Internecie od ludzi z tym problemem (linki poniżej). W końcu zdecydowałem się na przywrócenie poprzedniej wersji kernela (release 4.14.y), na której *lirc* działa i mam nadzieję, że konfiguracja *gpio-ir* w kolejnym release będzie dużo prostsza. Przywrócić kernela do **4.14.y** można wywołując komendę:
``` ssh
sudo rpi-update c30ae2bb624f7fd60fcbedff950cc4361c8d2aec
```

Przykładowe "rozwiązania" z Internetu:

- [Rozwiązanie poprzez patch od użytkownika neuralassembly](https://www.raspberrypi.org/forums/viewtopic.php?t=235256)  
- [Issue na **github'ie** z potencjalnym "rozwiązaniem" problemu i moim komentarzem](https://github.com/raspberrypi/linux/issues/2993)


> **ACHTUNG!** Powyższa instrukcja służy wyłącznie celom edukacyjnym. Wszystko to robisz na własną odpowiedzialność, a autor nie bierze odpowiedzialności za szkody powstałe w wyniku nierozważnych działań.


